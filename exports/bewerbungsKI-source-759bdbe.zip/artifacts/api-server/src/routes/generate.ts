import { Router } from "express";
import { db, profilesTable, generationResultsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";

const router = Router();

// A modest per-account daily limit protects the AI service from automated abuse.
const genUsage = new Map<string, { day: string; n: number }>();
function checkDailyGenQuota(userId: string): boolean {
  const day = new Date().toISOString().slice(0, 10);
  let u = genUsage.get(userId);
  if (!u || u.day !== day) { u = { day, n: 0 }; genUsage.set(userId, u); }
  if (u.n >= 10) return false;
  u.n++;
  if (genUsage.size > 10000) genUsage.clear();
  return true;
}

router.post("/generate", requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.userId!;
    const { type, systemPrompt, userPrompt, batchId } = req.body as {
      type: "cv" | "letter";
      systemPrompt: string;
      userPrompt: string;
      batchId: string;
    };
    if (
      !batchId ||
      !["cv", "letter"].includes(type) ||
      typeof systemPrompt !== "string" ||
      typeof userPrompt !== "string"
    ) {
      res.status(400).json({ error: "Invalid generation request" });
      return;
    }

    const [profile] = await db
      .select()
      .from(profilesTable)
      .where(eq(profilesTable.userId, userId));

    if (!profile?.emailVerifiedAt) {
      // New signups must confirm their email address before generating
      res.status(403).json({ error: "email_unverified" });
      return;
    }
    if (!checkDailyGenQuota(userId)) {
      res.status(429).json({ error: "daily_limit_reached" });
      return;
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      res.status(503).json({ error: "AI generation not configured. Please set ANTHROPIC_API_KEY." });
      return;
    }

    const factualityGuard = type === "cv"
      ? `VERBINDLICHE SICHERHEITSREGEL: Erstelle ausschließlich einen Lebenslauf. Verwende nur Fakten, die im Nutzertext ausdrücklich enthalten sind. Erfinde oder ergänze niemals Arbeitgeber, Positionen, Tätigkeiten, Erfolge, Ausbildung, Abschlüsse, Zeiträume, Kenntnisse, Sprachen oder persönliche Angaben. Fehlende Abschnitte bleiben leer; Lücken im Werdegang werden nicht erklärt oder gefüllt.`
      : `VERBINDLICHE SICHERHEITSREGEL: Erstelle ausschließlich ein Bewerbungsanschreiben. Verwende nur Fakten, die im Nutzertext ausdrücklich enthalten sind. Erfinde oder ergänze niemals Arbeitgeber, Positionen, Tätigkeiten, Erfolge, Ausbildung, Abschlüsse, Zeiträume, Kenntnisse oder persönliche Angaben.`;

    const callClaude = () =>
      fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-5",
          max_tokens: 4096,
          system: `${systemPrompt}\n\n${factualityGuard}`,
          messages: [{ role: "user", content: userPrompt }],
        }),
      });

    let response = await callClaude();

    // Bei Rate-Limit oder Überlastung: kurz warten und einmal erneut versuchen
    if (response.status === 429 || response.status === 529) {
      const retryAfter = parseFloat(response.headers.get("retry-after") || "");
      const waitSec = Math.min(Number.isFinite(retryAfter) ? retryAfter + 1 : 15, 40);
      req.log.warn({ waitSec }, "Claude rate limit/overloaded, retrying once");
      await new Promise((r) => setTimeout(r, waitSec * 1000));
      response = await callClaude();
    }

    if (!response.ok) {
      const errText = await response.text();
      req.log.error({ status: response.status, body: errText }, "Claude API error");
      if (response.status === 429 || response.status === 529) {
        res.status(503).json({ error: "busy_try_again" });
        return;
      }
      res.status(500).json({ error: "Generation failed" });
      return;
    }

    const data = await response.json() as {
      content: Array<{ type: string; text?: string }>;
    };

    let result = data.content?.find((b) => b.type === "text")?.text ?? "";
    // Strip Markdown code fences the model sometimes emits despite instructions
    result = result
      .replace(/^```(?:html|xml)?\s*/i, "")
      .replace(/\s*```\s*$/i, "")
      .trim();

    const [stored] = await db
      .insert(generationResultsTable)
      .values({ userId, batchId, type, fullText: result })
      .returning({ id: generationResultsTable.id });

    res.json({
      result,
      generationId: stored.id,
    });
  } catch (err) {
    req.log.error({ err }, "POST /generate error");
    res.status(500).json({ error: "Generation failed" });
  }
});

export default router;
