import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "../components/Layout";
import { useTranslation } from "react-i18next";
import { FileImportButton, type UploadedFile } from "../components/FileImportButton";
import { customFetch } from "@workspace/api-client-react";
import { detectImportedDocumentType, saveScanImport, saveWizardDesign, saveWizardPrefill } from "../lib/importHandoff";

export default function ImportPage() {
  const { t } = useTranslation();
  const [, navigate] = useLocation();
  const [text, setText] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [file, setFile] = useState<UploadedFile | null>(null);
  const [wizardBusy, setWizardBusy] = useState(false);

  const hasText = text.trim().length >= 80;

  function goScan(mode: "cv" | "letter") {
    try {
      saveScanImport(sessionStorage, text, mode);
    } catch { /* ignore */ }
    navigate("/scanner");
  }

  async function goWizard() {
    try { saveWizardPrefill(sessionStorage, text, detectImportedDocumentType(text)); } catch { /* ignore */ }
    // If a file (PDF/photo) was uploaded, copy its design too
    if (file) {
      setWizardBusy(true);
      try {
        const style = await customFetch("/api/design", {
          method: "POST",
          body: JSON.stringify({ mimeType: file.mimeType, data: file.base64 }),
        });
        saveWizardDesign(sessionStorage, style);
      } catch { /* design copy is best-effort */ }
      setWizardBusy(false);
    }
    navigate("/wizard");
  }

  const actionCard = (emoji: string, title: string, desc: string, onClick: () => void, disabled: boolean, busy?: boolean) => (
    <button
      onClick={onClick}
      disabled={disabled}
      className="card"
      style={{ textAlign: "start", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1, display: "flex", gap: 12, alignItems: "flex-start", width: "100%" }}
    >
      <span style={{ fontSize: 22, lineHeight: 1 }}>{busy ? <span className="spin" /> : emoji}</span>
      <span>
        <span style={{ display: "block", fontWeight: 700, fontSize: 14.5, marginBottom: 3 }}>{title}</span>
        <span style={{ display: "block", fontSize: 13, color: "var(--muted)", lineHeight: 1.5 }}>{desc}</span>
      </span>
    </button>
  );

  return (
    <Layout>
      <div style={{ maxWidth: 820, margin: "0 auto", padding: "28px 16px 60px" }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, marginBottom: 8 }}>📥 {t("importPage.title")}</h1>
        <p style={{ color: "var(--muted)", fontSize: 14.5, lineHeight: 1.6, marginBottom: 22 }}>{t("importPage.subtitle")}</p>

        <div className="card">
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, flexWrap: "wrap", marginBottom: 6 }}>
            <label style={{ fontWeight: 700, fontSize: 14 }}>{t("importPage.textLabel")}</label>
            <FileImportButton onText={(txt) => setText(txt)} onFile={setFile} />
          </div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t("importPage.placeholder")}
            rows={10}
            style={{ width: "100%", resize: "vertical", fontSize: 13.5, lineHeight: 1.6, padding: 12, borderRadius: 10, border: "1px solid var(--border)", background: "var(--bg2)", color: "var(--text)" }}
          />
          {errorMsg && <div style={{ color: "var(--err)", fontSize: 13.5, marginTop: 10 }}>{errorMsg}</div>}
        </div>

        <div style={{ fontWeight: 700, fontSize: 15, margin: "22px 0 10px" }}>{t("importPage.whatNext")}</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 10 }}>
          {actionCard("🔎", t("importPage.actCv"), t("importPage.actCvDesc"), () => goScan("cv"), !hasText)}
          {actionCard("✉️", t("importPage.actLetter"), t("importPage.actLetterDesc"), () => goScan("letter"), !hasText)}
          {actionCard("📝", t("importPage.actTemplate"), t("importPage.actTemplateDesc"), goWizard, !hasText || wizardBusy, wizardBusy)}
        </div>
      </div>
    </Layout>
  );
}
